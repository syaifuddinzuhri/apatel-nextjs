export { default as AuthShield } from "./components/auth-shield";
export { ComponentShield } from "./components/component-shield";
export type { AuthShieldProps } from "./types/props";
