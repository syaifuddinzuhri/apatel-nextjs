import type { ReactElement } from "react";

export type LayoutType = (page: ReactElement) => JSX.Element;
