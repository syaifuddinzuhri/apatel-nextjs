/* eslint-disable react-hooks/exhaustive-deps */
import { Box, useDisclosure, useMediaQuery } from "@chakra-ui/react";
import { useRouter } from "next/router";
import type { ReactNode } from "react";
import React, { useEffect } from "react";

import { useUserStore } from "@/stores/user";

interface IProps {
  children: ReactNode;
}

const DashboardLayout: React.FC<IProps> = ({ children }) => {
  const { isOpen, onOpen, onToggle, onClose } = useDisclosure({ defaultIsOpen: true });
  const setUser = useUserStore(state => state.setUser);
  const router = useRouter();

  const [isBreakpoint] = useMediaQuery("(min-width: 48rem)");

  useEffect(() => {
    const handleRouteChange = () => {};

    router.events.on("routeChangeStart", handleRouteChange);

    return () => {
      router.events.off("routeChangeStart", handleRouteChange);
    };
  }, [router]);

  useEffect(() => {
    // eslint-disable-next-line no-unused-expressions
    !isBreakpoint ? onClose() : onOpen();
  }, [isBreakpoint]);

  useEffect(() => {}, []);

  return (
    <Box minH="100vh">
      <Box
        minH={"100vh"}
        p={{ base: 3, md: 5 }}
        ml={{ base: 0, md: isOpen ? 60 : "100px" }}
        transition={"all 0.3s ease"}
      >
        {children}
      </Box>
    </Box>
  );
};

export default DashboardLayout;
